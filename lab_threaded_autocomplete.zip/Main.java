/*
I [_______] made the following modifications:
(Mark with an [X] every modification you did. Leave the rest blank [].)
	[] STOP ON EXCLAMATION
	[] STOP ON EXCLAMATION TIDIED
	[] QUIT TO EXIT
	[] BREAK BETWEEN WORDS
	[] MULTIWORD MATCH
	[] THREE BUTTON OUTPUT
*/
public class Main
{
	public static void main(String[] args)
	{
		SuggestionGUI application = new SuggestionGUI();
	}
}